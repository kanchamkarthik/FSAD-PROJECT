import { useState } from 'react';
import axios from 'axios';
import { Search, Loader, AlertCircle, MessageSquare, Send, User, CheckCircle2, Circle } from 'lucide-react';
import { MapContainer, TileLayer, Marker } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for default marker icon in leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

function TrackStatus() {
  const [issueId, setIssueId] = useState('');
  const [issue, setIssue] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [newComment, setNewComment] = useState('');
  const [submittingComment, setSubmittingComment] = useState(false);

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!issueId) return;
    
    setLoading(true);
    setError('');
    setIssue(null);
    
    try {
      const response = await axios.get(`http://localhost:8080/api/issues/${issueId}`);
      if (response.data) {
        setIssue(response.data);
      } else {
        setError('Issue not found. Please check your tracking ID.');
      }
    } catch (err) {
      console.error(err);
      setError('Could not find an issue with that ID. Ensure it was typed correctly.');
    } finally {
      setLoading(false);
    }
  };

  const handleAddComment = async (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    setSubmittingComment(true);
    try {
      const res = await axios.post(`http://localhost:8080/api/issues/${issue.id}/comment`, {
        text: newComment,
        userId: 1 // Simulated User ID 1 (Citizen) for demonstration
      });
      setIssue({
         ...issue,
         comments: [...(issue.comments || []), res.data]
      });
      setNewComment('');
    } catch (err) {
      console.error(err);
      alert('Failed to add comment');
    } finally {
      setSubmittingComment(false);
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '3rem auto' }}>
      <div className="card" style={{ textAlign: 'center', padding: '3rem 2rem' }}>
        <h2 style={{ marginBottom: '1rem' }}>Track Your Complaint</h2>
        <p style={{ color: 'var(--text-muted)', marginBottom: '2rem' }}>
          Enter the ID given to you when you submitted your report.
        </p>

        <form onSubmit={handleSearch} style={{ display: 'flex', gap: '0.5rem', marginBottom: '2rem' }}>
          <input 
            type="number"
            className="form-control"
            placeholder="Enter Issue ID (e.g. 1)"
            value={issueId}
            onChange={(e) => setIssueId(e.target.value)}
            style={{ flex: 1 }}
          />
          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? <Loader size={20} className="spin" /> : <Search size={20} />}
            Track
          </button>
        </form>

        {error && (
          <div style={{ padding: '1rem', background: '#FEF2F2', color: '#991B1B', borderRadius: 'var(--radius-md)', display: 'flex', alignItems: 'center', gap: '0.5rem', justifyContent: 'center' }}>
            <AlertCircle size={20} />
            {error}
          </div>
        )}

        {issue && (
          <div style={{ textAlign: 'left', borderTop: '1px solid var(--border)', paddingTop: '2rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
              <h3 style={{ fontSize: '1.25rem' }}>{issue.title}</h3>
              <span className={`badge badge-${(issue.status || 'OPEN').toLowerCase().replace('_', '-')}`} style={{ fontSize: '1rem', padding: '0.5rem 1rem' }}>
                {issue.status || 'OPEN'}
              </span>
            </div>
            
            {/* STATUS TIMELINE */}
            <div style={{ margin: '2rem 0', padding: '1.5rem', background: 'var(--background)', borderRadius: 'var(--radius-md)' }}>
                <h4 style={{ marginBottom: '1.5rem', borderBottom: '1px solid var(--border)', paddingBottom: '0.5rem' }}>Tracking Status</h4>
                <div style={{ display: 'flex', justifyContent: 'space-between', position: 'relative' }}>
                    <div style={{ position: 'absolute', top: '12px', left: '10%', right: '10%', height: '3px', background: 'var(--border)', zIndex: 0 }}></div>
                    {["OPEN", "IN_PROGRESS", "RESOLVED"].map((step, index) => {
                        const statusArray = ["OPEN", "IN_PROGRESS", "RESOLVED"];
                        const currentStatusIndex = statusArray.indexOf(issue.status || "OPEN");
                        const isCompleted = currentStatusIndex >= index;
                        const isCurrent = currentStatusIndex === index;
                        
                        return (
                            <div key={index} style={{ zIndex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.5rem', flex: 1, background: 'transparent' }}>
                                <div style={{ background: 'var(--background)', borderRadius: '50%', padding: '2px' }}>
                                    {isCompleted ? (
                                        <CheckCircle2 size={28} color="var(--secondary)" fill="var(--background)" strokeWidth={2} />
                                    ) : (
                                        <Circle size={28} color="var(--border)" fill="var(--background)" />
                                    )}
                                </div>
                                <span style={{ fontSize: '0.85rem', fontWeight: isCurrent ? 'bold' : 'normal', color: isCompleted ? 'var(--text-main)' : 'var(--text-muted)' }}>
                                    {step === "OPEN" ? "Submitted" : step === "IN_PROGRESS" ? "Working" : "Completed"}
                                </span>
                            </div>
                        )
                    })}
                </div>
            </div>

            <div style={{ display: 'grid', gap: '1rem', color: 'var(--text-muted)' }}>
              <div><strong>Category:</strong> {issue.category}</div>
              {issue.locationAddress && <div><strong>Location:</strong> {issue.locationAddress}</div>}
              <div><strong>Submitted On:</strong> {new Date(issue.createdAt || Date.now()).toLocaleString()}</div>
              <div><strong>Description:</strong> <br/> {issue.description || 'No additional details provided.'}</div>
            </div>

            {/* UPLOADED IMAGE */}
            {issue.imageUrl && (
                <div style={{ marginTop: '1.5rem' }}>
                    <strong>Attached Evidence:</strong>
                    <div style={{ marginTop: '0.5rem', borderRadius: 'var(--radius-md)', overflow: 'hidden', border: '1px solid var(--border)' }}>
                        <img src={issue.imageUrl} alt="Issue Evidence" style={{ width: '100%', display: 'block', maxHeight: '400px', objectFit: 'contain', background: '#e5e7eb' }} />
                    </div>
                </div>
            )}

            {/* MAP TRACKER */}
            {(issue.latitude || issue.lat) && (issue.longitude || issue.lng) && (
                <div style={{ marginTop: '1.5rem', borderRadius: 'var(--radius-md)', overflow: 'hidden', border: '1px solid var(--border)', height: '250px' }}>
                    <MapContainer center={[issue.latitude || issue.lat, issue.longitude || issue.lng]} zoom={15} style={{ height: "100%", width: "100%" }}>
                        <TileLayer
                            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        />
                        <Marker position={[issue.latitude || issue.lat, issue.longitude || issue.lng]} />
                    </MapContainer>
                </div>
            )}
            
            <div style={{ marginTop: '2rem', padding: '1.5rem', background: 'var(--background)', borderRadius: 'var(--radius-md)' }}>
              <h4 style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem', borderBottom: '1px solid var(--border)', paddingBottom: '0.5rem' }}>
                <MessageSquare size={20} /> Discussion Timeline
              </h4>
              
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginBottom: '1.5rem', maxHeight: '300px', overflowY: 'auto', paddingRight: '0.5rem' }}>
                {(!issue.comments || issue.comments.length === 0) ? (
                    <p style={{ color: 'var(--text-muted)', fontStyle: 'italic', textAlign: 'center', padding: '1rem 0' }}>No comments yet.</p>
                ) : (
                  issue.comments.map((comment, index) => {
                    const isUser = !comment.user || comment.user.role !== 'ADMIN';
                    return (
                        <div key={index} style={{ 
                            alignSelf: isUser ? 'flex-end' : 'flex-start',
                            maxWidth: '85%',
                            padding: '10px 15px', 
                            borderRadius: '16px', 
                            borderBottomRightRadius: isUser ? '4px' : '16px',
                            borderBottomLeftRadius: isUser ? '16px' : '4px',
                            background: isUser ? 'var(--background)' : 'rgba(79, 70, 229, 0.1)', 
                            border: '1px solid var(--border)',
                            boxShadow: 'var(--shadow-sm)'
                        }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                                <strong style={{ fontSize: '0.85rem', color: isUser ? 'var(--text-main)' : 'var(--primary)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                                  {isUser ? <User size={12} /> : null}
                                  {isUser ? (comment.user ? comment.user.name : 'Citizen') : 'Admin Official'} 
                                </strong>
                                <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                                  {new Date(comment.createdAt || Date.now()).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                </span>
                            </div>
                            <p style={{ margin: 0, fontSize: '0.95rem', color: 'var(--text-main)', wordBreak: 'break-word' }}>{comment.text || comment.message}</p>
                        </div>
                    );
                  })
                )}
              </div>

              <form onSubmit={handleAddComment} style={{ display: 'flex', gap: '0.5rem' }}>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Ask for an update or provide more details..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  style={{ flex: 1 }}
                />
                <button type="submit" className="btn btn-primary" disabled={submittingComment || !newComment.trim()}>
                  {submittingComment ? <Loader size={18} className="spin" /> : <Send size={18} />}
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default TrackStatus;
