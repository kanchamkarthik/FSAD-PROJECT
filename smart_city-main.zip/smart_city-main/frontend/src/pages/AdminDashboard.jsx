import { useState, useEffect, useMemo } from 'react';
import axios from 'axios';
import { AlertTriangle, CheckCircle, RefreshCw, MessageSquare, Search, Filter } from 'lucide-react';
import { toast } from 'react-toastify';

function AdminDashboard() {
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  useEffect(() => {
    fetchIssues();
  }, []);

  const fetchIssues = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/issues');
      setIssues(response.data);
    } catch (error) {
      console.error(error);
      setIssues([
        { id: 1, title: 'Large Pothole on Main St', category: 'Pothole', status: 'OPEN', locationAddress: '123 Main St' }
      ]); // mock fallback
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (id, newStatus) => {
    try {
      await axios.put(`http://localhost:8080/api/issues/${id}/status`, { status: newStatus });
      fetchIssues(); // Refresh list after update
      toast.success(`Issue #${id} status updated to ${newStatus}`);
    } catch (error) {
      console.error('Failed to update status', error);
      toast.error('Failed to update status (Backend connection error)');
    }
  };

  const addAdminComment = async (id) => {
    const text = prompt("Enter your comment as Admin (e.g. 'Work started'):");
    if (!text || !text.trim()) return;
    
    try {
      await axios.post(`http://localhost:8080/api/issues/${id}/comment`, {
        text: text,
        userId: 2 // Simulated Admin ID 2
      });
      toast.success('Admin comment added successfully!');
      fetchIssues();
    } catch(err) {
      console.error(err);
      toast.error('Failed to add admin comment.');
    }
  };

  const stats = useMemo(() => {
    const total = issues.length;
    const open = issues.filter(i => i.status === 'OPEN' || !i.status).length;
    const inProgress = issues.filter(i => i.status === 'IN_PROGRESS').length;
    const resolved = issues.filter(i => i.status === 'RESOLVED').length;
    return { total, open, inProgress, resolved };
  }, [issues]);

  const filteredIssues = useMemo(() => {
    return issues.filter(issue => {
      const matchStatus = statusFilter === 'ALL' || (issue.status || 'OPEN') === statusFilter;
      const matchSearch = issue.title.toLowerCase().includes(searchTerm.toLowerCase()) || issue.category.toLowerCase().includes(searchTerm.toLowerCase());
      return matchStatus && matchSearch;
    });
  }, [issues, statusFilter, searchTerm]);

  return (
    <div style={{ padding: '2rem 0' }}>
      <div className="page-header">
        <h2 className="page-title">Admin Issue Tracker</h2>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.5rem', marginBottom: '2rem' }}>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-hover) 100%)', color: 'white', border: 'none' }}>
          <div style={{ fontSize: '2.5rem', fontWeight: 800 }}>{stats.total}</div>
          <div style={{ opacity: 0.9 }}>Total Issues</div>
        </div>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', borderBottom: '4px solid var(--danger)' }}>
          <div style={{ fontSize: '2.5rem', fontWeight: 800, color: 'var(--danger)' }}>{stats.open}</div>
          <div style={{ color: 'var(--text-muted)', fontWeight: 600 }}>Open Issues</div>
        </div>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', borderBottom: '4px solid var(--warning)' }}>
          <div style={{ fontSize: '2.5rem', fontWeight: 800, color: 'var(--warning)' }}>{stats.inProgress}</div>
          <div style={{ color: 'var(--text-muted)', fontWeight: 600 }}>In Progress</div>
        </div>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', borderBottom: '4px solid var(--secondary)' }}>
          <div style={{ fontSize: '2.5rem', fontWeight: 800, color: 'var(--secondary)' }}>{stats.resolved}</div>
          <div style={{ color: 'var(--text-muted)', fontWeight: 600 }}>Resolved</div>
        </div>
      </div>

      <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.5rem', flexWrap: 'wrap' }}>
        <div style={{ flex: 3, position: 'relative', minWidth: '250px' }}>
          <Search size={20} style={{ position: 'absolute', left: '12px', top: '10px', color: 'var(--text-muted)' }} />
          <input 
            type="text" 
            className="form-control" 
            placeholder="Search by title or category..." 
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            style={{ paddingLeft: '40px' }}
          />
        </div>
        <div style={{ flex: 1, minWidth: '150px' }}>
            <select 
            className="form-control" 
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            >
            <option value="ALL">All Statuses</option>
            <option value="OPEN">Open</option>
            <option value="IN_PROGRESS">In Progress</option>
            <option value="RESOLVED">Resolved</option>
            </select>
        </div>
      </div>

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        {loading ? <p style={{ padding: '2rem', textAlign: 'center' }}>Loading issues...</p> : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                <thead style={{ background: 'rgba(0,0,0,0.02)' }}>
                <tr style={{ borderBottom: '1px solid var(--border)' }}>
                    <th style={{ padding: '1rem', color: 'var(--text-muted)', fontWeight: 600 }}>ID & Evidence</th>
                    <th style={{ padding: '1rem', color: 'var(--text-muted)', fontWeight: 600 }}>Title & Location</th>
                    <th style={{ padding: '1rem', color: 'var(--text-muted)', fontWeight: 600 }}>Category</th>
                    <th style={{ padding: '1rem', color: 'var(--text-muted)', fontWeight: 600 }}>Status</th>
                    <th style={{ padding: '1rem', color: 'var(--text-muted)', fontWeight: 600 }}>Actions</th>
                </tr>
                </thead>
                <tbody>
                {filteredIssues.map(issue => (
                    <tr key={issue.id} style={{ borderBottom: '1px solid var(--border)' }}>
                    <td style={{ padding: '1rem' }}>
                        <div style={{ fontWeight: 'bold', marginBottom: '0.5rem' }}>#{issue.id}</div>
                        {issue.imageUrl && (
                            <img src={issue.imageUrl} alt="Evidence" style={{ width: '60px', height: '60px', objectFit: 'cover', borderRadius: '4px', border: '1px solid var(--border)' }} />
                        )}
                    </td>
                    <td style={{ padding: '1rem' }}>
                        <div style={{ fontWeight: 500, fontSize: '1.05rem', color: 'var(--text-main)' }}>{issue.title}</div>
                        <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '0.25rem' }}>{issue.locationAddress}</div>
                    </td>
                    <td style={{ padding: '1rem' }}>
                        <span style={{ fontSize: '0.875rem', fontWeight: 500 }}>{issue.category}</span>
                    </td>
                    <td style={{ padding: '1rem' }}>
                        <span className={`badge badge-${(issue.status || 'OPEN').toLowerCase().replace('_', '-')}`}>
                        {issue.status || 'OPEN'}
                        </span>
                    </td>
                    <td style={{ padding: '1rem', display: 'flex', gap: '0.5rem', flexWrap: 'wrap', minWidth: '150px' }}>
                        {(issue.status === 'OPEN' || !issue.status) && (
                        <button 
                            className="btn btn-outline" 
                            style={{ padding: '0.25rem 0.5rem', fontSize: '0.875rem' }}
                            onClick={() => updateStatus(issue.id, 'IN_PROGRESS')}
                        >
                            <RefreshCw size={14} /> Start
                        </button>
                        )}
                        {(issue.status === 'OPEN' || issue.status === 'IN_PROGRESS' || !issue.status) && (
                        <button 
                            className="btn btn-outline" 
                            style={{ padding: '0.25rem 0.5rem', fontSize: '0.875rem', color: 'var(--secondary)' }}
                            onClick={() => updateStatus(issue.id, 'RESOLVED')}
                        >
                            <CheckCircle size={14} /> Resolve
                        </button>
                        )}
                        <button 
                            className="btn btn-outline" 
                            style={{ padding: '0.25rem 0.5rem', fontSize: '0.875rem', border: '1px solid #9CA3AF' }}
                            onClick={() => addAdminComment(issue.id)}
                        >
                            <MessageSquare size={14} /> Reply
                        </button>
                    </td>
                    </tr>
                ))}
                {filteredIssues.length === 0 && (
                    <tr>
                        <td colSpan="5" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)' }}>
                            No issues match your current filters.
                        </td>
                    </tr>
                )}
                </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default AdminDashboard;
