import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Camera, MapPin, LocateFixed } from 'lucide-react';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

const mapContainerStyle = {
  width: '100%',
  height: '350px',
  borderRadius: '0.5rem',
  border: '1px solid var(--border)',
  overflow: 'hidden'
};

// Default center set to Hyderabad, India
const center = {
  lat: 17.3850,
  lng: 78.4867
};

// Fix for default marker icon in leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

function MapClickHandler({ setCoords, setFormData, formData }) {
  useMapEvents({
    click(e) {
      const lat = e.latlng.lat;
      const lng = e.latlng.lng;
      setCoords({ lat, lng });
      if(!formData.locationAddress || formData.locationAddress.includes("Selected from map")) {
          setFormData(prev => ({ 
          ...prev, 
          locationAddress: `Lat: ${lat.toFixed(4)}, Lng: ${lng.toFixed(4)} (Selected from map)` 
          }));
      }
    },
  });
  return null;
}

function ReportIssue() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    title: '',
    category: 'Pothole',
    description: '',
    locationAddress: '',
  });
  
  const [coords, setCoords] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [file, setFile] = useState(null);
  const [locating, setLocating] = useState(false);

  const handleDetectLocation = () => {
    if (!navigator.geolocation) {
        alert("Geolocation is not supported by your browser");
        return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition((position) => {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        setCoords({ lat, lng });
        setFormData(prev => ({ 
            ...prev, 
            locationAddress: `Lat: ${lat.toFixed(4)}, Lng: ${lng.toFixed(4)} (Auto-detected)` 
        }));
        setLocating(false);
    }, () => {
        alert("Unable to retrieve your location");
        setLocating(false);
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!coords) {
        alert("Please select a location on the map.");
        return;
    }
    
    setSubmitting(true);
    
    try {
      let imageUrl = null;
      if (file) {
         imageUrl = URL.createObjectURL(file); // mock url
      }

      await axios.post('http://localhost:8080/api/issues', {
        ...formData,
        lat: coords.lat,
        lng: coords.lng,
        imageUrl: imageUrl
      });
      alert('Issue reported successfully!');
      navigate('/track');
    } catch (error) {
      console.error(error);
      if (error.response && (error.response.status === 401 || error.response.status === 403)) {
        alert('Please log in to report an issue.');
      } else {
        alert('Failed to report issue. Backend might be down.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '2rem 0' }}>
      <div className="page-header">
        <h2 className="page-title">Report a Civic Issue</h2>
      </div>

      <div className="card">
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Issue Title</label>
            <input 
              type="text" 
              className="form-control" 
              required
              value={formData.title}
              onChange={e => setFormData({...formData, title: e.target.value})}
              placeholder="E.g., Deep pothole near intersection"
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <div className="form-group">
              <label className="form-label">Category</label>
              <select 
                className="form-control"
                value={formData.category}
                onChange={e => setFormData({...formData, category: e.target.value})}
              >
                <option value="Pothole">Pothole</option>
                <option value="Garbage">Garbage / Waste</option>
                <option value="Streetlight">Broken Streetlight</option>
                <option value="Water">Water Leak</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Photo Evidence (Optional)</label>
              <div style={{ position: 'relative' }}>
                <input 
                  type="file" 
                  onChange={e => setFile(e.target.files[0])}
                  style={{ opacity: 0, position: 'absolute', width: '100%', height: '100%', cursor: 'pointer' }}
                />
                <div className="btn btn-outline" style={{ width: '100%' }}>
                  <Camera size={20} />
                  {file ? file.name : "Upload Image"}
                </div>
              </div>
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Accurate Location (Powered by OpenStreetMap)</label>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                <p style={{ fontSize: '0.875rem', color: 'var(--text-muted)', margin: 0 }}>
                  Click directly on the map to place an accurate pin, or auto-detect.
                </p>
                <button type="button" className="btn btn-outline" style={{ fontSize: '0.875rem', padding: '0.25rem 0.75rem', color: 'var(--primary)' }} onClick={handleDetectLocation} disabled={locating}>
                    <LocateFixed size={16} /> {locating ? 'Detecting...' : 'Auto Detect'}
                </button>
            </div>
            
            <div style={mapContainerStyle}>
                <MapContainer center={[center.lat, center.lng]} zoom={12} style={{ height: "100%", width: "100%", zIndex: 1 }}>
                <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                />
                <MapClickHandler setCoords={setCoords} setFormData={setFormData} formData={formData} />
                {coords && <Marker position={[coords.lat, coords.lng]} />}
                </MapContainer>
            </div>

            {coords && (
              <input 
                type="text" 
                className="form-control" 
                style={{ marginTop: '0.5rem' }}
                placeholder="Address Details (Optional)"
                value={formData.locationAddress}
                onChange={e => setFormData({...formData, locationAddress: e.target.value})}
              />
            )}
          </div>

          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea 
              className="form-control" 
              rows="4"
              value={formData.description}
              onChange={e => setFormData({...formData, description: e.target.value})}
              placeholder="Provide any additional details..."
            ></textarea>
          </div>

          <button type="submit" className="btn btn-primary" disabled={submitting}>
            {submitting ? 'Submitting...' : 'Submit Report'}
          </button>
        </form>
      </div>
    </div>
  );
}

export default ReportIssue;
