import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { AlertCircle, PlusCircle, MapPin, Eye, Activity, Target } from 'lucide-react';

function Home() {
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchIssues();
  }, []);

  const fetchIssues = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/issues');
      setIssues(response.data.slice(0, 3)); // show top 3 recent
    } catch (error) {
      console.error("Error fetching issues:", error);
      setIssues([
        { id: 1, title: 'Large Pothole on Main St', category: 'Pothole', status: 'OPEN', locationAddress: '123 Main St' },
        { id: 2, title: 'Broken Streetlight', category: 'Streetlight', status: 'IN_PROGRESS', locationAddress: '45 Elm St' }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const statusColors = {
    'OPEN': 'badge-open',
    'IN_PROGRESS': 'badge-in-progress',
    'RESOLVED': 'badge-resolved',
  };

  return (
    <div>
      {/* Hero Section */}
      <div className="hero" style={{ position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'relative', zIndex: 1 }}>
            <h1 style={{ fontWeight: 800, letterSpacing: '-0.025em' }}>Transform Your City</h1>
            <p style={{ fontSize: '1.25rem', opacity: 0.9, maxWidth: '600px', margin: '0 auto 2.5rem' }}>
                Help us identify and fix civic issues in your neighborhood. Be the eyes and ears of a smarter city today.
            </p>
            <Link to="/report" className="btn btn-primary" style={{ fontSize: '1.125rem', padding: '1rem 2rem', borderRadius: '50px', background: 'white', color: 'var(--primary)', fontWeight: 700, boxShadow: '0 10px 25px rgba(0,0,0,0.2)', transition: 'transform 0.3s ease' }}
                onMouseOver={e => e.currentTarget.style.transform = 'scale(1.05)'}
                onMouseOut={e => e.currentTarget.style.transform = 'scale(1)'}
            >
                <PlusCircle size={24} />
                Report an Issue Now
            </Link>
        </div>
        {/* Background decorative elements */}
        <div style={{ position: 'absolute', top: '-50%', left: '-10%', width: '300px', height: '300px', background: 'rgba(255,255,255,0.1)', borderRadius: '50%', filter: 'blur(50px)' }}></div>
        <div style={{ position: 'absolute', bottom: '-50%', right: '-10%', width: '300px', height: '300px', background: 'rgba(255,255,255,0.1)', borderRadius: '50%', filter: 'blur(50px)' }}></div>
      </div>

      {/* Feature Highlights Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '2rem', margin: '4rem 0' }}>
        <div className="card" style={{ textAlign: 'center', borderTop: '4px solid var(--primary)', background: 'var(--surface)' }}>
            <div style={{ background: 'rgba(79, 70, 229, 0.1)', width: '64px', height: '64px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.5rem', color: 'var(--primary)' }}>
                <MapPin size={32} />
            </div>
            <h3 style={{ marginBottom: '1rem' }}>Report Issues Easily</h3>
            <p style={{ color: 'var(--text-muted)' }}>Snap a photo, auto-detect your location, and submit your complaint in under 30 seconds.</p>
        </div>
        <div className="card" style={{ textAlign: 'center', borderTop: '4px solid var(--warning)', background: 'var(--surface)' }}>
            <div style={{ background: 'rgba(245, 158, 11, 0.1)', width: '64px', height: '64px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.5rem', color: 'var(--warning)' }}>
                <Activity size={32} />
            </div>
            <h3 style={{ marginBottom: '1rem' }}>Track in Real-Time</h3>
            <p style={{ color: 'var(--text-muted)' }}>Follow your complaint's progress with a clear Swiggy-style timeline and chat with officials.</p>
        </div>
        <div className="card" style={{ textAlign: 'center', borderTop: '4px solid var(--secondary)', background: 'var(--surface)' }}>
            <div style={{ background: 'rgba(16, 185, 129, 0.1)', width: '64px', height: '64px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.5rem', color: 'var(--secondary)' }}>
                <Eye size={32} />
            </div>
            <h3 style={{ marginBottom: '1rem' }}>Transparent Governance</h3>
            <p style={{ color: 'var(--text-muted)' }}>Hold authorities accountable with public dashboards showing resolution status and statistics.</p>
        </div>
      </div>

      <div className="page-header" style={{ marginBottom: '1.5rem' }}>
        <h2 className="page-title" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}><Target size={28} color="var(--primary)" /> Recent Activity</h2>
        <Link to="/track" className="btn btn-outline" style={{ fontSize: '0.875rem' }}>View All</Link>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '3rem' }}><p>Loading recent activity...</p></div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.5rem' }}>
          {issues.map(issue => (
            <div key={issue.id} className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
                <span className={`badge badge-${(issue.status || 'OPEN').toLowerCase().replace('_', '-')}`}>{issue.status || 'OPEN'}</span>
                <span style={{ fontSize: '0.875rem', color: 'var(--text-muted)', fontWeight: 600 }}>{issue.category}</span>
              </div>
              <h3 style={{ marginBottom: '0.5rem', fontSize: '1.125rem' }}>{issue.title}</h3>
              <p style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', color: 'var(--text-muted)', fontSize: '0.875rem', marginBottom: '1rem' }}>
                <AlertCircle size={16} />
                {issue.locationAddress || 'Location pending'}
              </p>
              {issue.imageUrl && (
                  <div style={{ width: '100%', height: '120px', borderRadius: '4px', overflow: 'hidden' }}>
                      <img src={issue.imageUrl} style={{ width: '100%', height: '100%', objectFit: 'cover' }} alt="Issue Thumbnail" />
                  </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Home;
