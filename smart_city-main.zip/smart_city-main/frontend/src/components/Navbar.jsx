import { useState, useEffect, useContext } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { MapPin, Moon, Sun, LogOut, User as UserIcon } from 'lucide-react';
import { AuthContext } from '../context/AuthContext';

function Navbar() {
  const { user, logout } = useContext(AuthContext);
  const location = useLocation();
  const navigate = useNavigate();
  const isActive = (path) => location.pathname === path ? 'active' : '';
  const [dark, setDark] = useState(false);

  useEffect(() => {
    if (localStorage.getItem('theme') === 'dark' || dark) {
        setDark(true);
        document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleDark = () => {
    const isDark = !dark;
    setDark(isDark);
    if (isDark) {
        document.documentElement.classList.add('dark');
        localStorage.setItem('theme', 'dark');
    } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('theme', 'light');
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="navbar">
      <div className="container navbar-content">
        <Link to="/" className="brand">
          <MapPin size={24} color="var(--primary)" />
          <span>SmartCity <small style={{ fontWeight: 400, opacity: 0.8 }}>Report</small></span>
        </Link>
        <div className="nav-links">
          <Link to="/" className={`nav-link ${isActive('/')}`}>Home</Link>
          <Link to="/track" className={`nav-link ${isActive('/track')}`}>Track</Link>
          
          {user ? (
            <>
              <Link to="/report" className={`nav-link ${isActive('/report')}`}>Report Issue</Link>
              {user.role === 'ADMIN' && (
                <Link to="/admin" className={`nav-link ${isActive('/admin')}`}>Admin</Link>
              )}
              <div style={{ width: '1px', height: '20px', background: 'var(--border)', margin: '0 0.5rem' }}></div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--text-main)', fontSize: '0.9rem', fontWeight: 600 }}>
                  <UserIcon size={16} /> {user.name}
              </div>
              <button onClick={handleLogout} className="btn btn-outline" style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', padding: '0.4rem 0.8rem', fontSize: '0.875rem' }}>
                <LogOut size={16} /> Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className={`nav-link ${isActive('/login')}`}>Login</Link>
              <Link to="/register" className="btn btn-primary" style={{ padding: '0.5rem 1rem', fontSize: '0.875rem' }}>Sign Up</Link>
            </>
          )}

          <button 
            onClick={toggleDark} 
            style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: '8px', width: '36px', height: '36px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'var(--text-main)', marginLeft: '0.5rem' }}
            title="Toggle Dark Mode"
          >
            {dark ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
