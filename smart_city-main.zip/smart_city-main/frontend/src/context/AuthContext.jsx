import { createContext, useState, useEffect } from 'react';
import axios from 'axios';

export const AuthContext = createContext();

export function AuthProvider({ children }) {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const token = localStorage.getItem('token');
        const role = localStorage.getItem('role');
        const id = localStorage.getItem('userId');
        const name = localStorage.getItem('name');

        if (token && id) {
            setUser({ id, role, name, token });
            // Add interceptor
            axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
        }
        setLoading(false);
    }, []);

    const login = (userData) => {
        localStorage.setItem('token', userData.jwt);
        localStorage.setItem('role', userData.role);
        localStorage.setItem('userId', userData.userId);
        localStorage.setItem('name', userData.name);
        setUser({ id: userData.userId, role: userData.role, name: userData.name, token: userData.jwt });
        axios.defaults.headers.common['Authorization'] = `Bearer ${userData.jwt}`;
    };

    const logout = () => {
        localStorage.clear();
        setUser(null);
        delete axios.defaults.headers.common['Authorization'];
    };

    return (
        <AuthContext.Provider value={{ user, login, logout, loading }}>
            {!loading && children}
        </AuthContext.Provider>
    );
}
