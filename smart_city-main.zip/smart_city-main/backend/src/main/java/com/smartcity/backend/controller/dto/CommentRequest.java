package com.smartcity.backend.controller.dto;

import lombok.Data;

@Data
public class CommentRequest {
    private String text;
    private Long userId; // The ID of the user creating the comment
}
