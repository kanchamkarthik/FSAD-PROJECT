package com.smartcity.backend.entity;

public enum IssueStatus {
    OPEN,
    IN_PROGRESS,
    RESOLVED
}
