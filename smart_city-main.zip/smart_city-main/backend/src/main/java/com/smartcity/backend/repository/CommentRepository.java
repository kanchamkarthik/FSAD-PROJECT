package com.smartcity.backend.repository;

import com.smartcity.backend.entity.Comment;
import com.smartcity.backend.entity.Issue;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Long> {
    List<Comment> findByIssue(Issue issue);
}
