package com.smartcity.backend.config;

import com.smartcity.backend.entity.User;
import com.smartcity.backend.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataLoader {

    @Bean
    public CommandLineRunner loadData(UserRepository userRepository) {
        return args -> {
            if (userRepository.count() == 0) {
                User user = new User();
                user.setName("John Doe");
                user.setEmail("john@example.com");
                user.setPassword("password");
                user.setRole("USER");
                userRepository.save(user);

                User admin = new User();
                admin.setName("Admin User");
                admin.setEmail("admin@smartcity.com");
                admin.setPassword("admin");
                admin.setRole("ADMIN");
                userRepository.save(admin);
            }
        };
    }
}
