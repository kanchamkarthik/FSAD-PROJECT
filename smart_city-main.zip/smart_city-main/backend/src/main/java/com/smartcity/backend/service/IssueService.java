package com.smartcity.backend.service;

import com.smartcity.backend.entity.Comment;
import com.smartcity.backend.entity.Issue;
import com.smartcity.backend.entity.IssueStatus;
import com.smartcity.backend.entity.User;
import com.smartcity.backend.repository.CommentRepository;
import com.smartcity.backend.repository.IssueRepository;
import com.smartcity.backend.repository.UserRepository;
import com.smartcity.backend.controller.dto.CommentRequest;

import org.springframework.lang.NonNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class IssueService {

    @Autowired
    private IssueRepository issueRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CommentRepository commentRepository;

    public List<Issue> getAllIssues() {
        return issueRepository.findAllByOrderByCreatedAtDesc();
    }

    @NonNull
    public Issue createIssue(@NonNull Issue issue, @NonNull Long userId) {
        Optional<User> userOpt = userRepository.findById(userId);
        if(userOpt.isPresent()) {
            issue.setUser(userOpt.get());
        }
        return issueRepository.save(issue);
    }

    @NonNull
    public Issue updateIssueStatus(@NonNull Long id, @NonNull IssueStatus status) {
        Optional<Issue> optionalIssue = issueRepository.findById(id);
        if (optionalIssue.isPresent()) {
            Issue issue = optionalIssue.get();
            issue.setStatus(status);
            return issueRepository.save(issue);
        }
        throw new RuntimeException("Issue not found");
    }

    @NonNull
    public Comment addCommentToIssue(@NonNull Long issueId, @NonNull CommentRequest request) {
        Optional<Issue> optionalIssue = issueRepository.findById(issueId);
        if (optionalIssue.isPresent()) {
            Issue issue = optionalIssue.get();
            
            Comment comment = new Comment();
            comment.setText(request.getText());
            comment.setIssue(issue);
            
            Long userId = request.getUserId() != null ? request.getUserId() : 1L; // Fallback to 1
            Optional<User> optionalUser = userRepository.findById(userId);
            if (optionalUser.isPresent()) {
                comment.setUser(optionalUser.get());
            } else {
                // If it's the admin or a known system user, handle it
                User placeholder = new User();
                placeholder.setId(userId);
                placeholder.setName("System User");
                placeholder.setRole("ADMIN");
                // comment.setUser(placeholder); // This would need saving first to satisfy constraints
            }
            // Better yet, just find by ID and link if present
            optionalUser.ifPresent(comment::setUser);

            return commentRepository.save(comment);
        }
        throw new RuntimeException("Issue not found");
    }
}
