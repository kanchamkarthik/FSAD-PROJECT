package com.smartcity.backend.repository;

import com.smartcity.backend.entity.Issue;
import com.smartcity.backend.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface IssueRepository extends JpaRepository<Issue, Long> {
    List<Issue> findByUser(User user);
    List<Issue> findAllByOrderByCreatedAtDesc();
}
