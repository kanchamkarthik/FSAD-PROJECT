package com.smartcity.backend.controller;

import org.springframework.lang.NonNull;
import com.smartcity.backend.entity.Issue;
import com.smartcity.backend.entity.IssueStatus;
import com.smartcity.backend.entity.Comment;
import com.smartcity.backend.entity.User;
import com.smartcity.backend.controller.dto.CommentRequest;
import com.smartcity.backend.service.IssueService;
import com.smartcity.backend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/issues")
public class IssueController {

    @Autowired
    private IssueService issueService;

    @Autowired
    private UserRepository userRepository;

    private long getCurrentUserId() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof UserDetails) {
            String email = ((UserDetails) principal).getUsername();
            Optional<User> userOpt = userRepository.findByEmail(email);
            if(userOpt.isPresent() && userOpt.get().getId() != null){
                return userOpt.get().getId();
            }
        }
        return 1L;
    }

    @GetMapping
    public List<Issue> getAllIssues() {
        return issueService.getAllIssues();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Issue> getIssueById(@PathVariable Long id) {
        return issueService.getAllIssues().stream()
                .filter(issue -> issue.getId().equals(id))
                .findFirst()
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Issue createIssue(@RequestBody @NonNull Issue issue) {
        return issueService.createIssue(issue, getCurrentUserId());
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<Issue> updateStatus(@PathVariable @NonNull Long id, @RequestBody Map<String, String> body) {
        String statusStr = body.get("status");
        if (statusStr == null) throw new RuntimeException("Status is required");
        IssueStatus status = IssueStatus.valueOf(statusStr);
        Issue updated = issueService.updateIssueStatus(id, status);
        return ResponseEntity.ok(updated);
    }

    @PostMapping("/{id}/comment")
    public ResponseEntity<Comment> addComment(@PathVariable @NonNull Long id, @RequestBody CommentRequest request) {
        request.setUserId(getCurrentUserId());
        Comment comment = issueService.addCommentToIssue(id, request);
        return ResponseEntity.ok(comment);
    }
}
